"""
Engine Framework - CLI Interface
================================

Comandos de linha de comando usando Click/Typer.
"""
